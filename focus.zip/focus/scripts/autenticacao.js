
const CHAVE_USUARIOS = 'focus_usuarios';
const CHAVE_SESSAO   = 'focus_sessao';

function cadastrarUsuario(nome, email, senha) {
  const usuarios = lerStorage(CHAVE_USUARIOS, []);

  const jaExiste = usuarios.find(u => u.email === email.toLowerCase());
  if (jaExiste) {
    return { ok: false, erro: 'Este e-mail já está cadastrado.' };
  }

  const novoUsuario = {
    id:           gerarId('usr'),
    nome:         nome.trim(),
    email:        email.toLowerCase().trim(),
    senha:        senha,
    dataCadastro: dataHoje(),
    pontos:       0,
    nivel:        1,
    sequencia:    0,
    ultimoAcesso: dataHoje()
  };

  usuarios.push(novoUsuario);
  salvarStorage(CHAVE_USUARIOS, usuarios);

  _criarSessao(novoUsuario);

  return { ok: true };
}

function fazerLogin(email, senha) {
  const usuarios = lerStorage(CHAVE_USUARIOS, []);

  const usuario = usuarios.find(
    u => u.email === email.toLowerCase().trim() && u.senha === senha
  );

  if (!usuario) {
    return { ok: false, erro: 'E-mail ou senha incorretos.' };
  }

  _atualizarSequencia(usuario);
  _criarSessao(usuario);

  return { ok: true };
}

function fazerLogout() {
  removerStorage(CHAVE_SESSAO);
  window.location.href = '../pages/login.html';
}

function obterSessao() {
  return lerStorage(CHAVE_SESSAO, null);
}

function exigirLogin() {
  const sessao = obterSessao();
  if (!sessao) {
    window.location.href = '../pages/login.html';
    return null;
  }
  return sessao; 
}

function obterUsuarioAtual() {
  const sessao = obterSessao();
  if (!sessao) return null;
  const usuarios = lerStorage(CHAVE_USUARIOS, []);
  return usuarios.find(u => u.id === sessao.id) || null;
}

function adicionarPontos(quantidade) {
  const sessao = obterSessao();
  if (!sessao) return;

  const usuarios = lerStorage(CHAVE_USUARIOS, []);
  const idx = usuarios.findIndex(u => u.id === sessao.id);
  if (idx === -1) return;

  usuarios[idx].pontos += quantidade;
  usuarios[idx].nivel = Math.floor(usuarios[idx].pontos / 100) + 1;
  salvarStorage(CHAVE_USUARIOS, usuarios);
}
function _criarSessao(usuario) {
  salvarStorage(CHAVE_SESSAO, {
    id:    usuario.id,
    nome:  usuario.nome,
    email: usuario.email
  });
}

function _atualizarSequencia(usuario) {
  const ontem = new Date();
  ontem.setDate(ontem.getDate() - 1);
  const ontemStr = ontem.toISOString().split('T')[0];

  if (usuario.ultimoAcesso === ontemStr) {
    usuario.sequencia += 1; 
  } else if (usuario.ultimoAcesso !== dataHoje()) {
    usuario.sequencia = 1; 
  }
  usuario.ultimoAcesso = dataHoje();

  const usuarios = lerStorage(CHAVE_USUARIOS, []);
  const idx = usuarios.findIndex(u => u.id === usuario.id);
  if (idx !== -1) {
    usuarios[idx] = { ...usuarios[idx], ...usuario };
    salvarStorage(CHAVE_USUARIOS, usuarios);
  }
}