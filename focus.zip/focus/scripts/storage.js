function lerStorage(chave, padrao = null) {
  const dado = localStorage.getItem(chave);
  if (!dado) return padrao;
  try {
    return JSON.parse(dado);
  } catch {
    return padrao;
  }
}

// converte objeto em JSON e salva
function salvarStorage(chave, valor) {
  localStorage.setItem(chave, JSON.stringify(valor));
}

// remove uma chave
function removerStorage(chave) {
  localStorage.removeItem(chave);
}

// gera um ID único
function gerarId(prefixo = 'id') {
  return `${prefixo}_${Date.now()}`;
}

// retorna a data de hoje em YYYY-MM-DD
function dataHoje() {
  return new Date().toISOString().split('T')[0];
}