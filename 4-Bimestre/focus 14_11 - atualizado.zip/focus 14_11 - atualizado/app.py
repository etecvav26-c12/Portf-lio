import os
from datetime import date, timedelta

from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

from tabelas import db, Usuario, Tarefa, Estudo, Resgate, Categoria

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__, static_folder='static', static_url_path='')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'focus.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'troque-esta-chave-por-uma-bem-aleatoria-antes-de-publicar'
db.init_app(app)

LOJA_RECOMPENSAS = [
    # Item de TESTE: barato, só para experimentar o resgate.
    {'id': 'rec_1', 'titulo': 'Pausa Café', 'desc': 'Item de teste: 15 minutos de intervalo para saborear um café quentinho.', 'custo': 50, 'imagem': 'assets/images/rewards/pausa-cafe.png', 'teste': True},
    # Prêmios de verdade: exigem muitos pontos (ganhos estudando).
    {'id': 'rec_2', 'titulo': 'Caneca Focus', 'desc': 'Caneca exclusiva para acompanhar suas maratonas de estudo.', 'custo': 2000, 'imagem': 'assets/images/rewards/caneca.png', 'teste': False},
    {'id': 'rec_3', 'titulo': 'Caderno Focus', 'desc': 'Caderno de capa dura para organizar resumos e anotações.', 'custo': 3000, 'imagem': 'assets/images/rewards/caderno.png', 'teste': False},
    {'id': 'rec_4', 'titulo': 'Mousepad Gamer', 'desc': 'Mousepad grande com base antiderrapante para a sua mesa de estudo e jogo.', 'custo': 5000, 'imagem': 'assets/images/rewards/mousepad.png', 'teste': False},
    {'id': 'rec_5', 'titulo': 'Camisa Focus', 'desc': 'Camisa oficial Focus para mostrar que você estuda com foco.', 'custo': 6000, 'imagem': 'assets/images/rewards/camisa.png', 'teste': False},
    {'id': 'rec_6', 'titulo': 'Mouse Gamer', 'desc': 'Mouse gamer com iluminação RGB e alta precisão.', 'custo': 9000, 'imagem': 'assets/images/rewards/mouse-gamer.png', 'teste': False},
    {'id': 'rec_7', 'titulo': 'Teclado Gamer', 'desc': 'Teclado mecânico gamer com iluminação RGB.', 'custo': 14000, 'imagem': 'assets/images/rewards/teclado-gamer.png', 'teste': False},
    {'id': 'rec_8', 'titulo': 'Fone de Ouvido', 'desc': 'Fone over-ear com ótimo som, perfeito para focar nos estudos.', 'custo': 18000, 'imagem': 'assets/images/rewards/fone.png', 'teste': False},
]


def data_hoje_str():
    return date.today().isoformat()


def exigir_login():
    uid = session.get('user_id')
    if not uid:
        return None
    return Usuario.query.get(uid)


def recalcular_sequencia(usuario):
    datas = set(e.data for e in usuario.estudos)
    if not datas:
        usuario.sequencia = 0
        return
    hoje = data_hoje_str()
    ontem = (date.today() - timedelta(days=1)).isoformat()
    if hoje not in datas and ontem not in datas:
        usuario.sequencia = 0
        return
    ref = date.fromisoformat(hoje if hoje in datas else ontem)
    seq = 0
    while ref.isoformat() in datas:
        seq += 1
        ref -= timedelta(days=1)
    usuario.sequencia = seq


def recalcular_nivel(usuario):
    usuario.nivel = usuario.pontos // 200 + 1


def adicionar_pontos(usuario, quantidade):
    usuario.pontos = max(0, usuario.pontos + quantidade)
    recalcular_nivel(usuario)

@app.route('/')
def home_page():
    return send_from_directory(app.static_folder, 'index.html')


@app.route('/api/auth/cadastro', methods=['POST'])
def cadastro():
    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    email = (dados.get('email') or '').strip().lower()
    senha = dados.get('senha') or ''

    if len(nome) < 2:
        return jsonify({'ok': False, 'erro': 'Informe seu nome completo.'}), 400
    if '@' not in email or '.' not in email:
        return jsonify({'ok': False, 'erro': 'Informe um e-mail válido.'}), 400
    if len(senha) < 6:
        return jsonify({'ok': False, 'erro': 'A senha deve ter pelo menos 6 caracteres.'}), 400
    if Usuario.query.filter_by(email=email).first():
        return jsonify({'ok': False, 'erro': 'Este e-mail já está cadastrado.'}), 409

    usuario = Usuario(
        nome=nome, email=email,
        senha_hash=generate_password_hash(senha),
        pontos=0, nivel=1, sequencia=0,
        ultimo_acesso=data_hoje_str(),
        data_cadastro=data_hoje_str(),
        meta_diaria_minutos=360
    )
    db.session.add(usuario)
    db.session.commit()

    session['user_id'] = usuario.id
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/auth/login', methods=['POST'])
def login():
    dados = request.get_json(force=True) or {}
    email = (dados.get('email') or '').strip().lower()
    senha = dados.get('senha') or ''

    usuario = Usuario.query.filter_by(email=email).first()
    if not usuario or not check_password_hash(usuario.senha_hash, senha):
        return jsonify({'ok': False, 'erro': 'E-mail ou senha incorretos.'}), 401

    usuario.ultimo_acesso = data_hoje_str()
    recalcular_sequencia(usuario)
    db.session.commit()

    session['user_id'] = usuario.id
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'ok': True})


@app.route('/api/auth/me', methods=['GET'])
def me():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'ok': False}), 401
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/tarefas', methods=['GET'])
def listar_tarefas():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([t.to_dict() for t in usuario.tarefas])


@app.route('/api/tarefas', methods=['POST'])
def criar_tarefa():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    if not nome:
        return jsonify({'erro': 'Informe o nome da tarefa.'}), 400

    prazo = (dados.get('prazo') or '').strip() or None
    if prazo:
        try:
            date.fromisoformat(prazo)
        except ValueError:
            return jsonify({'erro': 'Prazo inválido.'}), 400
    responsavel = ' '.join((dados.get('responsavel') or '').split())[:40] or None

    tarefa = Tarefa(
        usuario_id=usuario.id, nome=nome,
        materia=dados.get('materia') or 'Estudos',
        prioridade=dados.get('prioridade') or 'Média',
        prazo=prazo, responsavel=responsavel,
        concluida=False, data_criacao=data_hoje_str()
    )
    db.session.add(tarefa)
    db.session.commit()
    return jsonify(tarefa.to_dict()), 201

@app.route('/api/tarefas/<int:tarefa_id>', methods=['PUT'])
def editar_tarefa(tarefa_id):
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    tarefa = Tarefa.query.filter_by(id=tarefa_id, usuario_id=usuario.id).first()
    if not tarefa:
        return jsonify({'erro': 'Tarefa não encontrada.'}), 404

    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    if not nome:
        return jsonify({'erro': 'Informe o nome da tarefa.'}), 400
    prioridade = dados.get('prioridade')
    if prioridade not in ('Alta', 'Média', 'Baixa'):
        return jsonify({'erro': 'Prioridade inválida.'}), 400
    materia = ' '.join((dados.get('materia') or '').split())[:80]
    if not materia:
        return jsonify({'erro': 'Informe a matéria.'}), 400
    prazo = (dados.get('prazo') or '').strip() or None
    if prazo:
        try:
            date.fromisoformat(prazo)
        except ValueError:
            return jsonify({'erro': 'Prazo inválido.'}), 400
    responsavel = ' '.join((dados.get('responsavel') or '').split())[:40] or None

    tarefa.nome = nome[:200]
    tarefa.prioridade = prioridade
    tarefa.materia = materia
    tarefa.prazo = prazo
    tarefa.responsavel = responsavel
    db.session.commit()
    return jsonify(tarefa.to_dict())
    
@app.route('/api/tarefas/<int:tarefa_id>/concluir', methods=['PATCH'])
def alternar_tarefa(tarefa_id):
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    tarefa = Tarefa.query.filter_by(id=tarefa_id, usuario_id=usuario.id).first()
    if not tarefa:
        return jsonify({'erro': 'Tarefa não encontrada.'}), 404
    tarefa.concluida = not tarefa.concluida  # nunca altera pontos
    db.session.commit()
    return jsonify(tarefa.to_dict())


@app.route('/api/tarefas/<int:tarefa_id>', methods=['DELETE'])
def excluir_tarefa(tarefa_id):
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    tarefa = Tarefa.query.filter_by(id=tarefa_id, usuario_id=usuario.id).first()
    if not tarefa:
        return jsonify({'erro': 'Tarefa não encontrada.'}), 404
    db.session.delete(tarefa)
    db.session.commit()
    return jsonify({'ok': True})


# ---------- Categorias personalizadas ----------
CATEGORIAS_PADRAO = ['Matemática', 'Física', 'Redação', 'TCC', 'Química', 'Biologia', 'História', 'Geografia', 'Outros']


@app.route('/api/categorias', methods=['GET'])
def listar_categorias():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([c.to_dict() for c in usuario.categorias])


@app.route('/api/categorias', methods=['POST'])
def criar_categoria():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    nome = ' '.join((dados.get('nome') or '').split())
    if len(nome) < 2:
        return jsonify({'ok': False, 'erro': 'Digite um nome com pelo menos 2 letras.'}), 400
    if len(nome) > 40:
        return jsonify({'ok': False, 'erro': 'O nome da categoria pode ter no máximo 40 caracteres.'}), 400

    existentes = [n.lower() for n in CATEGORIAS_PADRAO] + [c.nome.lower() for c in usuario.categorias]
    if nome.lower() in existentes:
        return jsonify({'ok': False, 'erro': 'Essa categoria já existe.'}), 409

    categoria = Categoria(usuario_id=usuario.id, nome=nome)
    db.session.add(categoria)
    db.session.commit()
    return jsonify({'ok': True, 'categoria': categoria.to_dict()}), 201


@app.route('/api/categorias/<int:categoria_id>', methods=['DELETE'])
def excluir_categoria(categoria_id):
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    categoria = Categoria.query.filter_by(id=categoria_id, usuario_id=usuario.id).first()
    if not categoria:
        return jsonify({'erro': 'Categoria não encontrada.'}), 404
    db.session.delete(categoria)
    db.session.commit()
    return jsonify({'ok': True})


# ---------- Estudos (única fonte de pontos) ----------
@app.route('/api/estudos', methods=['GET'])
def listar_estudos():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([e.to_dict() for e in usuario.estudos])


@app.route('/api/estudos', methods=['POST'])
def registrar_estudo():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    materia = dados.get('materia') or 'Estudos'
    try:
        duracao = int(dados.get('duracaoMinutos', 0))
    except (TypeError, ValueError):
        duracao = 0
    if duracao < 1:
        return jsonify({'erro': 'Duração inválida.'}), 400
    duracao = min(duracao, 180)  # trava contra sessões absurdas

    pontos = duracao * 10
    estudo = Estudo(
        usuario_id=usuario.id, materia=materia, duracao=duracao,
        data=data_hoje_str(), pontos_ganhos=pontos
    )
    db.session.add(estudo)
    adicionar_pontos(usuario, pontos)
    recalcular_sequencia(usuario)
    db.session.commit()

    return jsonify({
        'ok': True, 'estudo': estudo.to_dict(),
        'pontosGanhos': pontos, 'usuario': usuario.to_dict()
    }), 201


# ---------- Recompensas ----------
@app.route('/api/recompensas', methods=['GET'])
def listar_loja():
    return jsonify(LOJA_RECOMPENSAS)


@app.route('/api/recompensas/resgatar', methods=['POST'])
def resgatar():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    recompensa = next((r for r in LOJA_RECOMPENSAS if r['id'] == dados.get('id')), None)
    if not recompensa:
        return jsonify({'ok': False, 'erro': 'Recompensa não encontrada.'}), 404
    if usuario.pontos < recompensa['custo']:
        return jsonify({'ok': False, 'erro': f"Pontos insuficientes. Você precisa de {recompensa['custo']} pts."}), 400

    adicionar_pontos(usuario, -recompensa['custo'])
    resgate = Resgate(
        usuario_id=usuario.id, recompensa_id=recompensa['id'],
        titulo=recompensa['titulo'], custo=recompensa['custo'], data=data_hoje_str()
    )
    db.session.add(resgate)
    db.session.commit()
    return jsonify({'ok': True, 'recompensa': recompensa, 'usuario': usuario.to_dict()})


@app.route('/api/recompensas/historico', methods=['GET'])
def historico_resgates():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([r.to_dict() for r in usuario.resgates])


# ---------- Configurações ----------
@app.route('/api/config/perfil', methods=['POST'])
def salvar_perfil():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    email = (dados.get('email') or '').strip().lower()
    if len(nome) < 2:
        return jsonify({'ok': False, 'erro': 'Informe seu nome completo.'}), 400
    if '@' not in email:
        return jsonify({'ok': False, 'erro': 'Informe um e-mail válido.'}), 400
    existente = Usuario.query.filter(Usuario.email == email, Usuario.id != usuario.id).first()
    if existente:
        return jsonify({'ok': False, 'erro': 'Este e-mail já está em uso por outra conta.'}), 409

    usuario.nome = nome
    usuario.email = email
    db.session.commit()
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/config/meta-diaria', methods=['POST'])
def salvar_meta():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    try:
        minutos = int(dados.get('minutos'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'erro': 'Valor inválido.'}), 400
    usuario.meta_diaria_minutos = minutos
    db.session.commit()
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/config/reset', methods=['POST'])
def resetar_dados():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    Tarefa.query.filter_by(usuario_id=usuario.id).delete()
    Estudo.query.filter_by(usuario_id=usuario.id).delete()
    Resgate.query.filter_by(usuario_id=usuario.id).delete()
    Categoria.query.filter_by(usuario_id=usuario.id).delete()
    usuario.pontos = 0
    usuario.nivel = 1
    usuario.sequencia = 0
    db.session.commit()
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, port=5000)