const API_BASE = '/api';
let usuarioAtual = null;

async function api(caminho, opcoes = {}) {
  const resposta = await fetch(API_BASE + caminho, {
    method: opcoes.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    credentials: 'include',
    body: opcoes.body ? JSON.stringify(opcoes.body) : undefined
  });
  let dados = null;
  try { dados = await resposta.json(); } catch (_) {}
  if (!resposta.ok) {
    const erro = new Error((dados && dados.erro) || 'Erro na requisição.');
    erro.dados = dados;
    throw erro;
  }
  return dados;
}

async function cadastrarUsuario(nome, email, senha) {
  try {
    const res = await api('/auth/cadastro', { method: 'POST', body: { nome, email, senha } });
    usuarioAtual = res.usuario;
    return { ok: true };
  } catch (e) { return { ok: false, erro: e.dados?.erro || e.message }; }
}

async function fazerLogin(email, senha) {
  try {
    const res = await api('/auth/login', { method: 'POST', body: { email, senha } });
    usuarioAtual = res.usuario;
    return { ok: true };
  } catch (e) { return { ok: false, erro: e.dados?.erro || e.message }; }
}

async function fazerLogout() {
  try { await api('/auth/logout', { method: 'POST' }); } catch (_) {}
  window.location.href = 'login.html';
}

async function exigirLoginAsync() {
  try {
    const res = await api('/auth/me');
    usuarioAtual = res.usuario;
    return usuarioAtual;
  } catch (e) {
    window.location.href = 'login.html';
    return null;
  }
}

async function obterUsuarioAtual() {
  try {
    const res = await api('/auth/me');
    usuarioAtual = res.usuario;
    return usuarioAtual;
  } catch (e) { return null; }
}

async function obterTarefas() { return api('/tarefas'); }
async function salvarTarefa(nome, materia, prioridade, prazo = null, responsavel = null) {
  return api('/tarefas', { method: 'POST', body: { nome, materia, prioridade, prazo, responsavel } });
}
async function concluirTarefa(id) { return api(`/tarefas/${id}/concluir`, { method: 'PATCH' }); }
async function excluirTarefa(id) { return api(`/tarefas/${id}`, { method: 'DELETE' }); }
async function editarTarefa(id, dados) {
  return api(`/tarefas/${id}`, { method: 'PUT', body: dados });
}

async function obterCategorias() { return api('/categorias'); }
async function salvarCategoria(nome) {
  try {
    const res = await api('/categorias', { method: 'POST', body: { nome } });
    return { ok: true, categoria: res.categoria };
  } catch (e) { return { ok: false, erro: e.dados?.erro || e.message }; }
}
async function excluirCategoria(id) { return api(`/categorias/${id}`, { method: 'DELETE' }); }

async function obterEstudos() { return api('/estudos'); }
async function registrarEstudo(materia, duracaoMinutos) {
  const res = await api('/estudos', { method: 'POST', body: { materia, duracaoMinutos } });
  usuarioAtual = res.usuario;
  return res;
}

async function obterLojaRecompensas() { return api('/recompensas'); }
async function resgatarRecompensa(id) {
  try {
    const res = await api('/recompensas/resgatar', { method: 'POST', body: { id } });
    usuarioAtual = res.usuario;
    return { ok: true, recompensa: res.recompensa };
  } catch (e) { return { ok: false, erro: e.dados?.erro || e.message }; }
}
async function obterResgatesUsuario() { return api('/recompensas/historico'); }

async function salvarPerfil(nome, email) {
  try {
    const res = await api('/config/perfil', { method: 'POST', body: { nome, email } });
    usuarioAtual = res.usuario;
    return { ok: true };
  } catch (e) { return { ok: false, erro: e.dados?.erro || e.message }; }
}
async function enviarFotoPerfil(arquivo) {
  try {
    const formulario = new FormData();

    formulario.append('foto', arquivo);

    const resposta = await fetch(
      API_BASE + '/config/foto-perfil',
      {
        method: 'POST',
        credentials: 'include',
        body: formulario
      }
    );

    const dados = await resposta.json();

    if (!resposta.ok) {
      throw new Error(dados.erro || 'Não foi possível enviar a foto.');
    }

    usuarioAtual = dados.usuario;

    return { ok: true };

  } catch (e) {
    return { ok: false, erro: e.message };
  }
}
async function removerFotoPerfil() {
  try {
    const dados = await api('/config/foto-perfil', {
      method: 'DELETE'
    });

    usuarioAtual = dados.usuario;

    return { ok: true };

  } catch (e) {
    return {
      ok: false,
      erro: e.dados?.erro || e.message
    };
  }
}
async function salvarMetaDiaria(minutos) {
  const res = await api('/config/meta-diaria', { method: 'POST', body: { minutos } });
  usuarioAtual = res.usuario;
  return res;
}
async function resetarDadosConta() {
  const res = await api('/config/reset', { method: 'POST' });
  usuarioAtual = res.usuario;
  return res;
}

function formatarDataLocal(date) {
  const ano = date.getFullYear();
  const mes = String(date.getMonth() + 1).padStart(2, '0');
  const dia = String(date.getDate()).padStart(2, '0');
  return `${ano}-${mes}-${dia}`;
}

async function obterAvisosTarefas() {
  let tarefas = [];
  try { tarefas = await obterTarefas(); } catch (_) { return []; }

  const hoje = formatarDataLocal(new Date());
  const amanhaData = new Date();
  amanhaData.setDate(amanhaData.getDate() + 1);
  const amanha = formatarDataLocal(amanhaData);

  const formatar = p => { const [a, m, d] = p.split('-'); return `${d}/${m}/${a}`; };
  const avisos = [];

  tarefas.filter(t => !t.concluida && t.prazo).forEach(t => {
    const prazo = String(t.prazo).slice(0, 10);
    if (prazo < hoje) {
      avisos.push({ tipo: 'vencida', ordem: prazo, texto: `"${t.nome}" venceu em ${formatar(prazo)}.` });
    } else if (prazo === hoje) {
      avisos.push({ tipo: 'hoje', ordem: prazo, texto: `"${t.nome}" vence hoje.` });
    } else if (prazo === amanha) {
      avisos.push({ tipo: 'amanha', ordem: prazo, texto: `"${t.nome}" vence amanhã (${formatar(prazo)}).` });
    }
  });

  return avisos.sort((a, b) => a.ordem.localeCompare(b.ordem));
}