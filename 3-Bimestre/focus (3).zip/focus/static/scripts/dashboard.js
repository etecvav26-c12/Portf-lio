async function inicializarShellDashboard(paginaAtiva) {
  usuarioAtual = await exigirLoginAsync();
  if (!usuarioAtual) return;

  const body = document.body;
  let container = document.querySelector('.dashboard-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'dashboard-container';
    const originalContent = Array.from(body.children);
    body.appendChild(container);

    const sidebarHTML = `
      <aside class="sidebar" id="sidebar-painel">
        <div class="sidebar__logo-container">
          <a href="home.html" style="display: flex; align-items: center; text-decoration: none;">
            <img src="../assets/images/Logo 1.png" alt="Focus" class="sidebar__logo-img">
          </a>
        </div>
        <ul class="sidebar__menu">
          <li class="sidebar__item"><a href="home.html" class="sidebar__link ${paginaAtiva === 'inicio' ? 'sidebar__link--active' : ''}"><i data-lucide="home"></i> Início</a></li>
          <li class="sidebar__item"><a href="tarefas.html" class="sidebar__link ${paginaAtiva === 'tarefas' ? 'sidebar__link--active' : ''}"><i data-lucide="check-square"></i> Tarefas</a></li>
          <li class="sidebar__item"><a href="estudos.html" class="sidebar__link ${paginaAtiva === 'estudos' ? 'sidebar__link--active' : ''}"><i data-lucide="book-open"></i> Estudos</a></li>
          <li class="sidebar__item"><a href="recompensas.html" class="sidebar__link ${paginaAtiva === 'recompensas' ? 'sidebar__link--active' : ''}"><i data-lucide="gift"></i> Recompensas</a></li>
          <li class="sidebar__item"><a href="desempenho.html" class="sidebar__link ${paginaAtiva === 'desempenho' ? 'sidebar__link--active' : ''}"><i data-lucide="bar-chart-2"></i> Desempenho</a></li>
          <li class="sidebar__item"><a href="configuracao.html" class="sidebar__link ${paginaAtiva === 'configuracao' ? 'sidebar__link--active' : ''}"><i data-lucide="settings"></i> Configuração</a></li>
        </ul>
        <div class="sidebar__footer">
          <div class="sidebar__logout" onclick="fazerLogout()"><i data-lucide="log-out"></i> Sair da conta</div>
        </div>
      </aside>
    `;

    const mainHTML = `
      <main class="dashboard-main">
        <header class="dashboard-header">
          <div style="display: flex; align-items: center; gap: 12px;">
            <button class="mobile-menu-toggle" id="menu-mobile-btn"><i data-lucide="menu"></i></button>
            <div class="header-greeting">
              <h1 id="header-nome-usuario">Olá, ${usuarioAtual.nome.split(' ')[0]}!</h1>
              <p>Continue sua jornada com foco</p>
            </div>
          </div>
          <div class="header-actions">
            <button class="notification-btn" id="notif-btn" title="Notificações">
              <i data-lucide="bell"></i><span class="notification-badge"></span>
            </button>
            <div class="user-profile-menu" id="perfil-btn">
              <div class="user-avatar-placeholder" title="${usuarioAtual.nome}"><i data-lucide="user"></i></div>
              <div class="user-info">
                <span class="user-name">${usuarioAtual.nome.split(' ')[0]}</span>
                <span class="user-level" id="header-user-level">Nível ${usuarioAtual.nivel} (${usuarioAtual.pontos} pts)</span>
              </div>
              <div class="profile-dropdown" id="perfil-dropdown">
                <a href="configuracao.html"><i data-lucide="user"></i> Meu Perfil</a>
                <a href="configuracao.html"><i data-lucide="settings"></i> Configurações</a>
                <hr>
                <button onclick="fazerLogout()"><i data-lucide="log-out" style="color: var(--cor-vermelho)"></i> Sair</button>
              </div>
            </div>
          </div>
        </header>
        <div class="dashboard-content" id="conteudo-painel-dinamico"></div>
      </main>
    `;

    container.innerHTML = sidebarHTML + mainHTML;
    const contentTarget = document.getElementById('conteudo-painel-dinamico');
    originalContent.forEach(node => { if (node.tagName !== 'SCRIPT') contentTarget.appendChild(node); });
  }

  configurarEventosPainel();
  if (window.lucide) lucide.createIcons();
}

async function atualizarHeaderUsuario() {
  usuarioAtual = await obterUsuarioAtual();
  if (!usuarioAtual) return;
  const headerNome = document.getElementById('header-nome-usuario');
  const headerLevel = document.getElementById('header-user-level');
  const userNames = document.querySelectorAll('.user-profile-menu .user-name');
  if (headerNome) headerNome.textContent = `Olá, ${usuarioAtual.nome.split(' ')[0]}!`;
  if (headerLevel) headerLevel.textContent = `Nível ${usuarioAtual.nivel} (${usuarioAtual.pontos} pts)`;
  userNames.forEach(el => { el.textContent = usuarioAtual.nome.split(' ')[0]; });
}

function configurarEventosPainel() {
  const menuBtn = document.getElementById('menu-mobile-btn');
  const sidebar = document.getElementById('sidebar-painel');
  const perfilBtn = document.getElementById('perfil-btn');
  const dropdown = document.getElementById('perfil-dropdown');
  const notifBtn = document.getElementById('notif-btn');

  if (menuBtn && sidebar) {
    menuBtn.onclick = e => { e.stopPropagation(); sidebar.classList.toggle('active'); };
  }
  document.addEventListener('click', e => {
    if (sidebar && sidebar.classList.contains('active') && !sidebar.contains(e.target) && e.target !== menuBtn) {
      sidebar.classList.remove('active');
    }
  });
  if (perfilBtn && dropdown) {
    perfilBtn.onclick = e => { e.stopPropagation(); dropdown.classList.toggle('active'); };
  }
  document.addEventListener('click', () => {
    if (dropdown && dropdown.classList.contains('active')) dropdown.classList.remove('active');
  });
  if (notifBtn) {
    notifBtn.onclick = () => {
      mostrarModalFeedback('Notificações', 'Você está em dia com seus estudos! Nenhuma notificação nova no momento.', 'bell');
      const badge = notifBtn.querySelector('.notification-badge');
      if (badge) badge.style.display = 'none';
    };
  }
}

function mostrarModalFeedback(titulo, descricao, iconeNome = 'check-circle') {
  const modalAntigo = document.getElementById('focus-modal-overlay-global');
  if (modalAntigo) modalAntigo.remove();
  const overlay = document.createElement('div');
  overlay.className = 'focus-modal-overlay';
  overlay.id = 'focus-modal-overlay-global';
  const modal = document.createElement('div');
  modal.className = 'focus-modal';
  modal.innerHTML = `
    <div class="focus-modal-icon" style="${iconeNome === 'alert-circle' ? 'background-color:#fee2e2; color:#ef4444' : ''}">
      <i data-lucide="${iconeNome}"></i>
    </div>
    <h3 class="focus-modal-title">${titulo}</h3>
    <p class="focus-modal-desc">${descricao}</p>
    <button class="focus-modal-btn" onclick="document.getElementById('focus-modal-overlay-global').remove()">Ok, entendi</button>
  `;
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  if (window.lucide) lucide.createIcons();
}

function removerAcentos(str) {
  return str.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}