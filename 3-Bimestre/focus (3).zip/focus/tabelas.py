from flask_sqlalchemy import SQLAlchemy 

db = SQLAlchemy()

class Usuario(db.Model):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    senha_hash = db.Column(db.String(255), nullable=False)
    pontos = db.Column(db.Integer, default=0)
    nivel = db.Column(db.Integer, default=1)
    sequencia = db.Column(db.Integer, default=0)
    ultimo_acesso = db.Column(db.String(10))
    data_cadastro = db.Column(db.String(10))
    meta_diaria_minutos = db.Column(db.Integer, default=360)

    tarefas = db.relationship('Tarefa', backref='usuario', cascade='all, delete-orphan')
    estudos = db.relationship('Estudo', backref='usuario', cascade='all, delete-orphan')
    resgates = db.relationship('Resgate', backref='usuario', cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id, 'nome': self.nome, 'email': self.email,
            'pontos': self.pontos, 'nivel': self.nivel, 'sequencia': self.sequencia,
            'metaDiariaMinutos': self.meta_diaria_minutos
        }


class Tarefa(db.Model):
    __tablename__ = 'tarefas'
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    nome = db.Column(db.String(200), nullable=False)
    materia = db.Column(db.String(80), default='Estudos')
    prioridade = db.Column(db.String(20), default='Média')
    concluida = db.Column(db.Boolean, default=False)
    data_criacao = db.Column(db.String(10))

    def to_dict(self):
        return {
            'id': self.id, 'nome': self.nome, 'materia': self.materia,
            'prioridade': self.prioridade, 'concluida': self.concluida,
            'dataCriacao': self.data_criacao
        }


class Estudo(db.Model):
    __tablename__ = 'estudos'
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    materia = db.Column(db.String(80), default='Estudos')
    duracao = db.Column(db.Integer, default=0)
    data = db.Column(db.String(10))
    pontos_ganhos = db.Column(db.Integer, default=0)

    def to_dict(self):
        return {
            'id': self.id, 'materia': self.materia, 'duracao': self.duracao,
            'data': self.data, 'pontosGanhos': self.pontos_ganhos
        }


class Resgate(db.Model):
    __tablename__ = 'resgates'
    id = db.Column(db.Integer, primary_key=True)
    usuario_id = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    recompensa_id = db.Column(db.String(20))
    titulo = db.Column(db.String(200))
    custo = db.Column(db.Integer)
    data = db.Column(db.String(10))

    def to_dict(self):
        return {
            'id': self.id, 'recompensaId': self.recompensa_id,
            'titulo': self.titulo, 'custo': self.custo, 'data': self.data
        }