import os
from datetime import date, timedelta

from flask import Flask, request, jsonify, session, send_from_directory
from werkzeug.security import generate_password_hash, check_password_hash

from tabelas import db, Usuario, Tarefa, Estudo, Resgate

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__, static_folder='static', static_url_path='')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(BASE_DIR, 'focus.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = 'troque-esta-chave-por-uma-bem-aleatoria-antes-de-publicar'
db.init_app(app)

LOJA_RECOMPENSAS = [
    {'id': 'rec_1', 'titulo': 'Pausa Café', 'desc': '15 minutos de intervalo para saborear um café quentinho e relaxar.', 'custo': 50, 'icone': 'coffee'},
    {'id': 'rec_2', 'titulo': 'Pausa Redes Sociais', 'desc': '15 minutos liberados para dar aquela checada no feed e stories.', 'custo': 100, 'icone': 'phone'},
    {'id': 'rec_3', 'titulo': 'Pausa Gamer', 'desc': '30 minutos jogando o seu game favorito sem culpa.', 'custo': 200, 'icone': 'gamepad-2'},
    {'id': 'rec_4', 'titulo': 'Episódio de Série', 'desc': 'Permissão para assistir a 1 episódio da sua série do momento.', 'custo': 300, 'icone': 'play-circle'},
    {'id': 'rec_5', 'titulo': 'Comprar um Livro/HQ', 'desc': 'Um mimo físico ou digital para alimentar o seu hábito de leitura.', 'custo': 1000, 'icone': 'book-open'},
    {'id': 'rec_6', 'titulo': 'Dia de Folga', 'desc': 'Um dia inteiro de folga planejada dos estudos para recarregar as energias.', 'custo': 2500, 'icone': 'sun'},
]


def data_hoje_str():
    return date.today().isoformat()


def exigir_login():
    uid = session.get('user_id')
    if not uid:
        return None
    return Usuario.query.get(uid)


def recalcular_sequencia(usuario):
    datas = set(e.data for e in usuario.estudos)
    if not datas:
        usuario.sequencia = 0
        return
    hoje = data_hoje_str()
    ontem = (date.today() - timedelta(days=1)).isoformat()
    if hoje not in datas and ontem not in datas:
        usuario.sequencia = 0
        return
    ref = date.fromisoformat(hoje if hoje in datas else ontem)
    seq = 0
    while ref.isoformat() in datas:
        seq += 1
        ref -= timedelta(days=1)
    usuario.sequencia = seq


def recalcular_nivel(usuario):
    usuario.nivel = usuario.pontos // 200 + 1


def adicionar_pontos(usuario, quantidade):
    usuario.pontos = max(0, usuario.pontos + quantidade)
    recalcular_nivel(usuario)

@app.route('/')
def home_page():
    return send_from_directory(app.static_folder, 'index.html')


@app.route('/api/auth/cadastro', methods=['POST'])
def cadastro():
    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    email = (dados.get('email') or '').strip().lower()
    senha = dados.get('senha') or ''

    if len(nome) < 2:
        return jsonify({'ok': False, 'erro': 'Informe seu nome completo.'}), 400
    if '@' not in email or '.' not in email:
        return jsonify({'ok': False, 'erro': 'Informe um e-mail válido.'}), 400
    if len(senha) < 6:
        return jsonify({'ok': False, 'erro': 'A senha deve ter pelo menos 6 caracteres.'}), 400
    if Usuario.query.filter_by(email=email).first():
        return jsonify({'ok': False, 'erro': 'Este e-mail já está cadastrado.'}), 409

    usuario = Usuario(
        nome=nome, email=email,
        senha_hash=generate_password_hash(senha),
        pontos=0, nivel=1, sequencia=0,
        ultimo_acesso=data_hoje_str(),
        data_cadastro=data_hoje_str(),
        meta_diaria_minutos=360
    )
    db.session.add(usuario)
    db.session.commit()

    session['user_id'] = usuario.id
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/auth/login', methods=['POST'])
def login():
    dados = request.get_json(force=True) or {}
    email = (dados.get('email') or '').strip().lower()
    senha = dados.get('senha') or ''

    usuario = Usuario.query.filter_by(email=email).first()
    if not usuario or not check_password_hash(usuario.senha_hash, senha):
        return jsonify({'ok': False, 'erro': 'E-mail ou senha incorretos.'}), 401

    usuario.ultimo_acesso = data_hoje_str()
    recalcular_sequencia(usuario)
    db.session.commit()

    session['user_id'] = usuario.id
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'ok': True})


@app.route('/api/auth/me', methods=['GET'])
def me():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'ok': False}), 401
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/tarefas', methods=['GET'])
def listar_tarefas():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([t.to_dict() for t in usuario.tarefas])


@app.route('/api/tarefas', methods=['POST'])
def criar_tarefa():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    if not nome:
        return jsonify({'erro': 'Informe o nome da tarefa.'}), 400

    tarefa = Tarefa(
        usuario_id=usuario.id, nome=nome,
        materia=dados.get('materia') or 'Estudos',
        prioridade=dados.get('prioridade') or 'Média',
        concluida=False, data_criacao=data_hoje_str()
    )
    db.session.add(tarefa)
    db.session.commit()
    return jsonify(tarefa.to_dict()), 201


@app.route('/api/tarefas/<int:tarefa_id>/concluir', methods=['PATCH'])
def alternar_tarefa(tarefa_id):
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    tarefa = Tarefa.query.filter_by(id=tarefa_id, usuario_id=usuario.id).first()
    if not tarefa:
        return jsonify({'erro': 'Tarefa não encontrada.'}), 404
    tarefa.concluida = not tarefa.concluida  # nunca altera pontos
    db.session.commit()
    return jsonify(tarefa.to_dict())


@app.route('/api/tarefas/<int:tarefa_id>', methods=['DELETE'])
def excluir_tarefa(tarefa_id):
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    tarefa = Tarefa.query.filter_by(id=tarefa_id, usuario_id=usuario.id).first()
    if not tarefa:
        return jsonify({'erro': 'Tarefa não encontrada.'}), 404
    db.session.delete(tarefa)
    db.session.commit()
    return jsonify({'ok': True})


# ---------- Estudos (única fonte de pontos) ----------
@app.route('/api/estudos', methods=['GET'])
def listar_estudos():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([e.to_dict() for e in usuario.estudos])


@app.route('/api/estudos', methods=['POST'])
def registrar_estudo():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    materia = dados.get('materia') or 'Estudos'
    try:
        duracao = int(dados.get('duracaoMinutos', 0))
    except (TypeError, ValueError):
        duracao = 0
    if duracao < 1:
        return jsonify({'erro': 'Duração inválida.'}), 400
    duracao = min(duracao, 180)  # trava contra sessões absurdas

    pontos = duracao * 10
    estudo = Estudo(
        usuario_id=usuario.id, materia=materia, duracao=duracao,
        data=data_hoje_str(), pontos_ganhos=pontos
    )
    db.session.add(estudo)
    adicionar_pontos(usuario, pontos)
    recalcular_sequencia(usuario)
    db.session.commit()

    return jsonify({
        'ok': True, 'estudo': estudo.to_dict(),
        'pontosGanhos': pontos, 'usuario': usuario.to_dict()
    }), 201


# ---------- Recompensas ----------
@app.route('/api/recompensas', methods=['GET'])
def listar_loja():
    return jsonify(LOJA_RECOMPENSAS)


@app.route('/api/recompensas/resgatar', methods=['POST'])
def resgatar():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    recompensa = next((r for r in LOJA_RECOMPENSAS if r['id'] == dados.get('id')), None)
    if not recompensa:
        return jsonify({'ok': False, 'erro': 'Recompensa não encontrada.'}), 404
    if usuario.pontos < recompensa['custo']:
        return jsonify({'ok': False, 'erro': f"Pontos insuficientes. Você precisa de {recompensa['custo']} pts."}), 400

    adicionar_pontos(usuario, -recompensa['custo'])
    resgate = Resgate(
        usuario_id=usuario.id, recompensa_id=recompensa['id'],
        titulo=recompensa['titulo'], custo=recompensa['custo'], data=data_hoje_str()
    )
    db.session.add(resgate)
    db.session.commit()
    return jsonify({'ok': True, 'recompensa': recompensa, 'usuario': usuario.to_dict()})


@app.route('/api/recompensas/historico', methods=['GET'])
def historico_resgates():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    return jsonify([r.to_dict() for r in usuario.resgates])


# ---------- Configurações ----------
@app.route('/api/config/perfil', methods=['POST'])
def salvar_perfil():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    nome = (dados.get('nome') or '').strip()
    email = (dados.get('email') or '').strip().lower()
    if len(nome) < 2:
        return jsonify({'ok': False, 'erro': 'Informe seu nome completo.'}), 400
    if '@' not in email:
        return jsonify({'ok': False, 'erro': 'Informe um e-mail válido.'}), 400
    existente = Usuario.query.filter(Usuario.email == email, Usuario.id != usuario.id).first()
    if existente:
        return jsonify({'ok': False, 'erro': 'Este e-mail já está em uso por outra conta.'}), 409

    usuario.nome = nome
    usuario.email = email
    db.session.commit()
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/config/meta-diaria', methods=['POST'])
def salvar_meta():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    dados = request.get_json(force=True) or {}
    try:
        minutos = int(dados.get('minutos'))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'erro': 'Valor inválido.'}), 400
    usuario.meta_diaria_minutos = minutos
    db.session.commit()
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


@app.route('/api/config/reset', methods=['POST'])
def resetar_dados():
    usuario = exigir_login()
    if not usuario:
        return jsonify({'erro': 'Não autenticado.'}), 401
    Tarefa.query.filter_by(usuario_id=usuario.id).delete()
    Estudo.query.filter_by(usuario_id=usuario.id).delete()
    Resgate.query.filter_by(usuario_id=usuario.id).delete()
    usuario.pontos = 0
    usuario.nivel = 1
    usuario.sequencia = 0
    db.session.commit()
    return jsonify({'ok': True, 'usuario': usuario.to_dict()})


with app.app_context():
    db.create_all()

if __name__ == '__main__':
    app.run(debug=True, port=5000)